# Changelog

All notable changes to AssetDoctor. Versioning is patch-only (0.1.x) until a change is
flagged as major.

## [0.1.0] — M0 Scaffold — unreleased

### Added
- Repo scaffold: `blender_manifest.toml` (Extension, Blender 5.0+), thin
  `register`/`unregister`, `AssetDoctorPreferences` (backup dir, auto-backup toggle,
  resolution-token regex).
- `core/` bpy-free package:
  - `report.py` — `Finding`/`Report` with JSON + CSV export. **Tested.**
  - `graph.py` — `DepGraph` with roots/leaves/cycle detection. **Tested.**
  - `fingerprint.py` — `strip_resolution_tokens` implemented & tested; node/mesh hashers
    stubbed for M2.
  - `blendscan.py` — BAT wrapper stub for M1.
- `ops/` scaffold operators (F1–F4) that register and report "implemented in M#".
- `ui/panels.py` — AssetDoctor N-panel with one button per feature.
- pytest harness (`conftest.py`, `pyproject.toml`) running the bpy-free core tests outside
  Blender; tests for report, graph, and `strip_resolution_tokens` (incl. doctests).
- `README.md`, `docs/ARCHITECTURE.md` (design + risks + milestone roadmap), `.gitignore`.

### Added (BAT bundling — TODO #2 resolved)
- Bundled `blender_asset_tracer==1.20` (pure-Python wheel) via `blender_manifest.toml`
  `wheels`. Confirmed `requests` is NOT required for dependency tracing (probe with
  requests blocked under Blender 5.1), so the requests/charset_normalizer chain is
  intentionally excluded to keep the extension cross-platform.
- `tests/smoke_register.py` (headless register/unregister + BAT-presence check) and
  `tests/probe_bat_imports.py` (confirms blendfile/trace import without requests).
- `[build] paths_exclude_pattern` so dev-only dirs stay out of the release zip.
- Verified: manifest parses, extension builds (`assetdoctor-0.1.0.zip`), and the addon
  registers/unregisters in Blender 5.1.

## [0.1.0] — M1: F1 folder link map — unreleased

### Added
- `core/blendscan.py` — BAT-backed offline reader: `scan_file` (reads `LI` Library
  blocks; Blender 5.x stores the path in the block's `name`, `//` = relative),
  `resolve_blend_relative`, `iter_blend_files`, and `map_folder` building the `DepGraph`.
- `core/graph.py` — added `to_dot()` Graphviz export.
- `core/f1_linkmap.py` — `build_link_report` flags broken links, absolute (non-portable)
  paths, circular references, unreadable files, plus a summary.
- `ops/scan_folder.py` — folder picker → report → writes `<root>/.assetdoctor/linkmap_*.{json,csv,dot}`.
- Fixtures: `tests/fixtures/build_linkproj.py` generates `linkproj/` (scene → libA → libB,
  relative links) — committed so pytest runs bpy-free. `tests/conftest.py` puts the BAT
  wheel on sys.path.
- Tests: `tests/test_blendscan.py` (7) — direct link, leaf, path resolution, transitive
  graph, clean-project report, broken-link detection, DOT smoke. `tests/smoke_f1.py`
  runs the operator end-to-end in Blender.

### Verified
- 28 pytest tests pass; F1 operator runs in Blender 5.1 (scene→libA→libB, exports written).

## [0.1.0] — M2: content fingerprinting — unreleased

### Added
- `core/fingerprint.py` — `fingerprint_material` (recursive hash from the Material Output,
  invariant to node naming/order, **resolution-agnostic** via image base-name),
  `fingerprint_mesh` (counts + rounded coords + topology, float-jitter tolerant),
  `fingerprint_image` (identity, resolution-SENSITIVE). Canonical JSON + SHA1 with float
  rounding.
- `ops/extract.py` — bpy→dict extractors (materials/meshes/images) feeding the hashers;
  generic node-prop extraction that skips cosmetic/layout attrs and normalises image refs.
- `core/cluster.py` — `group_identical` (fingerprint → duplicate groups), used by F3/F4/M6.
- Tests: `tests/test_fingerprint.py` (1K==2K equality, naming/order invariance,
  topology/param sensitivity, mesh tolerance, image res-sensitivity), `tests/test_cluster.py`,
  and `tests/smoke_fingerprint.py` validating the contract against real Blender 5.1 data.

### Verified
- 44 pytest tests pass. In Blender 5.1: a 1K and 2K material hash identically end-to-end;
  wood≠metal; mesh identity works; image identity stays resolution-sensitive.

## [0.1.0] — M3: F4 orphans, fake users & duplicates — unreleased

### Added
- `core/f4_orphans.py` — `classify` (orphan / fake_only / in_use / linked, per verified
  Blender 5.1 semantics: orphan=users0, fake_only=fake&users1) and `build_orphan_report`
  (orphan + fake-only lists, identity clusters via `group_identical` with per-member status,
  summary).
- `ops/orphans.py` — gathers datablocks across the common collections (materials/meshes/
  images fingerprinted), builds the report, and offers an optional `purge_orphans`
  (`bpy.data.orphans_purge`) behind the report-first/auto-backup safety model.
- `ops/safety.py` — `auto_backup` writes a timestamped `.blend` copy (save_as_mainfile
  copy=True) before any mutation, honouring the prefs backup dir / toggle.
- Tests: `tests/test_f4_orphans.py` (classification, orphan/fake lists, identity clusters,
  type isolation, linked exclusion, summary) + `tests/smoke_f4.py` end-to-end.

### Verified
- 50 pytest tests pass. In Blender 5.1: orphan/fake-only/identical classification correct;
  purge removes orphans while fake-user and in-use data survive.

## [0.1.0] — M4: F3 material dedup — unreleased

### Added
- `core/f3_materials.py` — `parse_name_list`, `choose_canonical` (whitelist > non-blacklisted
  > forced; tie-break local-over-linked then highest resolution), `build_dedup_plan`
  (fingerprint clusters → plan + report, flags linked victims).
- `ops/material_dedup.py` — gathers materials (fingerprint + max texture res + unique id that
  disambiguates local/linked same-name), report-first dry run; on Apply (after auto-backup)
  `user_remap`s duplicates onto the canonical and removes local victims. `REGISTER`+`UNDO`.
- `prefs.py` — `material_whitelist` / `material_blacklist` (comma/newline, glob-aware).
- Tests: `tests/test_f3_materials.py` (list parsing, all canonical-selection rules, plan +
  summary, linked-victim flagging) + `tests/smoke_f3.py` end-to-end.

### Verified
- 60 pytest tests pass. In Blender 5.1: a 1K+2K material pair clusters, the 2K wins canonical,
  Apply removes the 1K and repoints its object's slot to the 2K; whitelist override works.

## [0.1.5] — M7 step 4: Profile Render (real peak RAM)

### Added
- **Profile Render** button (Resource Analyzer): renders the current frame and reports
  Blender's **real peak system RAM** (whole process, via OS — Windows `GetProcessMemoryInfo`
  / Unix `getrusage`), shown in the Resource panel to complement the estimates.
  Real VRAM is intentionally not attempted (not exposed by Blender's Python API); F5's
  VRAM estimate covers that side.
- `core.resource.peak_process_ram_bytes()` (bpy-free) + test; `tests/smoke_profile.py`.

This completes **F5 / M7**.

## [0.1.4] — M8: Report system v2

### Added / changed (TODOs)
- **Persistent per-feature reports.** Each scan (Link Map / Make Local / Materials / Orphans /
  Geometry) keeps its OWN report — a Materials report survives a later Geometry scan. The
  Report panel gets a selector row to switch between whichever reports exist; clear removes
  only the shown one. (Replaces the single overwritten slot; F5 resource stays separate.)
- **Per-line tooltips.** Tree row labels are now tooltip-bearing buttons whose hover text is
  the FULL line (full broken-link path, full message + size) — readable despite the narrow
  panel. Clicking a row does its natural action (expand/collapse a parent, select a leaf).
- **Export/print.** "Export…" on the Report and Resource panels writes the current view to a
  `.txt` (indented tree) or `.csv` (reports) for printing/sharing.
- **Select-in-Outliner** (per chosen behaviour): selecting a finding selects + activates the
  user object(s) (Outliner follows the active object) without rearranging editors; a material
  also gets its slot highlighted; orphan/unused data shows a hint to use Outliner → Blender
  File / Orphan Data.
- Tests: `core/tree.all_keys` + updated `smoke_report.py` (persistence, selector, toggle,
  export, select, clear — 9/9).

## [0.1.3] — M7 step 3: F5 Resource Analyzer

### Added
- **Resource Analyzer (F5).** "Analyze Memory/Disk" estimates usage by **datablock type**
  (Images, Meshes, …), each datablock counted once, biggest-first, with est. RAM / est. VRAM /
  accurate disk + user count, shown in a new **Resource Usage** panel (reuses the tree widget).
  Chosen over a scene→object hierarchy to avoid double-counting shared data.
- `core/resource.py` (image/mesh byte estimates + `human_bytes`), `core/resource_tree.py`
  (by-type tree + totals), tree `detail` column + JSON (de)serialization, generalized expand
  toggle (works for both the report and resource trees).
- Tests: `test_resource.py`, `test_resource_tree.py` (+ tree round-trip) and `smoke_resource.py`.

### Changed (TODOs)
- Documentation icon pinned **far right** in the panel header (title · version · ⟶ icon).
- Debug log renamed **`AssetDoctorDebugLog.txt`** (was debugLog.txt).

## [0.1.2] — M7 step 2: instance duplicate geometry

### Added
- **Geometry dedup / instancing.** `core/geometry_dedup.py` (`build_instance_plan`,
  `choose_canonical`) finds identical-but-separate mesh datablocks used by different objects
  and plans to collapse them onto one shared datablock (turning wasteful copies into
  instances). Kind-agnostic engine; covers meshes now (curves/others extend via a fingerprint).
- `ops/instance_dedup.py` — report-first dry run; on Apply (after auto-backup) `user_remap`s
  duplicate meshes onto the canonical (most-used local one) and removes the copies. Panel:
  "Duplicate Geometry" box (report / apply). Report flows into the M7-step-1 viewer.
- Tests: `tests/test_geometry_dedup.py` + `tests/smoke_instance.py` (two identical separate
  meshes → instanced onto one; duplicate removed; distinct geometry untouched).

### Versioning
- **3rd-digit bump per completed step**; the N-panel header shows `vX.Y.Z` (from the manifest)
  so the installed build is verifiable. The built zip is named `assetdoctor-<version>.zip`.

## [0.1.1] — M7 step 1: report viewer (shared tree widget)

### Added
- **In-Blender report viewer.** Every feature now stashes its `Report` on the WindowManager
  and a collapsible **Report** panel renders it as an expandable tree (category → finding →
  item) with severity icons, expand/collapse toggles, and **click-to-select** the datablock a
  finding refers to (objects directly; materials/mesh-data via the objects that use them).
- `core/tree.py` (bpy-free): `TreeNode`/`Row`, `report_to_tree` (rolls up severity, parses
  `Type/Name` refs but not file paths), `flatten_visible` (tree + expanded keys → indented
  rows). `Report.from_dict`/`from_json` round-trip.
- `ops/report_store.py`: `stash_report` + toggle/clear/select operators.
- Tests: `tests/test_tree.py` (tree build, ref parsing, flatten/expand) + `tests/smoke_report.py`
  (operator → stash → reconstruct → toggle → select → clear, in Blender). Report round-trip test.

### Notes
- This is the shared widget the F5 Resource Analyzer (M7 step 3) will reuse. Panel *draw* is
  interactive; the data pipeline behind it is covered by tests.

## [0.1.0] — Build hygiene + compressed-file support — unreleased

### Fixed / clarified
- **Compressed .blend support confirmed.** Blender 5.x bundles `zstandard` (0.25.0 in 5.1)
  in its own Python, so BAT reads zstd-compressed files (Blender's default since 3.0) with
  nothing extra bundled. Locked by `tests/smoke_compressed.py`. (Our committed fixtures are
  uncompressed, which had hidden this.)
- **Removed a stray bundled `zstandard` wheel** from `wheels`/manifest and the
  **Windows-only `platforms` pin** that came with it — both unnecessary given the above, and
  the pin would have made the extension Windows-only. Package is platform-independent again
  and back to ~135 KB (was ~645 KB).
- **Excluded `tools/` from the shipped extension** (kept in the repo as a dev utility).
  `tools/find_billboards.py` is a host-Python offline object-name search; on host Python it
  needs `pip install zstandard` for compressed files (Blender's bundle doesn't apply there).

## [0.1.0] — Responsive scan + doc link (TODO 4 + doc icon) — unreleased

### Added
- **Modal folder scan** (TODO 4): the F1 scan runs as a modal operator — time-bounded batch
  per timer tick, **ESC to cancel**, live progress bar in the panel (WindowManager props),
  wait cursor and status-bar text. `core.blendscan` refactored into
  `new_scan_result`/`scan_into`/`map_folder`; `f1_linkmap.report_from_scan` shares report
  building between the modal and synchronous (`execute`) paths.
- **Documentation icon**: right-aligned HELP button on the panel header (`draw_header`) opening
  the repo docs; `website` added to `blender_manifest.toml`. (URL is a placeholder pending push.)
- Tests: incremental-vs-synchronous scan equivalence + `report_from_scan` + `bat_available`.

### Verified / pending
- 69 pytest tests pass (core of the modal scan verified: incremental == synchronous).
- Blender-side checks (register smoke, zip rebuild) and the interactive modal/progress + doc
  icon are pending — deferred to avoid competing with an active render.

## [0.1.0] — UX batch (TODO 1/2/5) — unreleased

### Added
- **Project folder field + Scan button** (TODO 5): `Scene.assetdoctor_scan_dir` path picker;
  the scan operator runs the stored folder (only opens the browser when none is set).
- **Tooltips** (TODO 1): per-variant `description()` classmethods on the make-local / dedup /
  orphans operators; descriptions on the new Scene props.
- **Utilities section + Enable Debug Log** (TODO 2): `Scene.assetdoctor_debug_log` toggle and
  `log.py` (an `assetdoctor` logger). INFO findings → console + file; DEBUG detail → file.
  `debugLog.txt` is written next to the .blend (or Blender temp if unsaved). All four
  operators now log instead of bare `print`.
- Tests: `tests/test_log.py` + `tests/smoke_utils.py`.

### Notes
- Deferred to a planned "M7: UX & feedback" milestone — report viewer (TODO 3) and
  progress/responsiveness via a modal folder-scan operator (TODO 4). See docs/TODO.md.

## [0.1.0] — M5: F2 recursive make-local — unreleased

### Added
- `core/f2_makelocal.py` — `build_makelocal_report` groups linked datablocks by source
  library, counts indirect (transitively-linked) ones, summary.
- `ops/make_local.py` — dry-run report; on Apply iterates `make_local(clear_liboverride=True)`
  over all ID collections until nothing is linked, then purges emptied libraries.
  - **New File** mode (default): writes a fully-local copy (`save_as_mainfile copy=True`) then
    `revert_mainfile()` so the working file's linked setup is untouched. Requires a saved file.
  - **In Place** mode: flattens the current file after an auto-backup.
- Tests: `tests/test_f2_makelocal.py` + `tests/smoke_f2.py` (New File output BAT-verified to
  have zero library links; In Place leaves no linked data and no libraries).

### Fixed / discovered
- After `make_local`, `Library.users` can report a phantom count even when `user_map()` shows
  no real users. `_purge_libraries` now trusts `user_map()` to remove stale libraries.
  Regression covered by `smoke_f2.py` ("no libraries remain").

### Verified
- 63 pytest tests pass. In Blender 5.1: both F2 modes correct on the scene→libA→libB fixture.

### Notes
- Next: M6 — F1 cross-file object-duplication census (reuses M2 fingerprints) + polish.
